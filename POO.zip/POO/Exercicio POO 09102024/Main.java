public class Main{
    public static void main(String[] args) {
        SistemaDeTarefas sistemaDeTarefas = new SistemaDeTarefas();
        sistemaDeTarefas.adicionarTarefa(new LimpezaDeSistema("num sei"));
        sistemaDeTarefas.adicionarTarefa(new RelatorioFinanceiro());
        sistemaDeTarefas.adicionarTarefa(new LimpezaDeSistema("nao sei"));
        sistemaDeTarefas.agendarTodas("09/10/2024 19:55:00");
        sistemaDeTarefas.executarTodas();
        sistemaDeTarefas.monitorarTarefas()
                .forEach(System.out::println);
//        for(StatusAgendamento status : sistemaDeTarefas.monitorarTarefas())
//            System.out.println(status);
    }
}