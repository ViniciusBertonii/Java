import java.util.List;
public class SistemaDeTarefas {
    private List<Agendavel> agendaveis;
    public void adicionarTarefa(Agendavel agendavel){
        agendaveis.add(agendavel);
    }
    public void agendarTodas(String horario){
//        for (Agendavel agendavel : agendaveis)agendavel.agendar(horario);
        agendaveis.forEach(agendavel -> agendavel.agendar(horario));
    }
    public void executarTodas(){
//        for (Agendavel agendavel : agendaveis) agendavel.executar();
        agendaveis.forEach(Agendavel::executar);
    }
    public List<StatusAgendamento> monitorarTarefas(){
//        List<StatusAgendamento> statusAgendamentos = new ArrayList<>(agendaveis.size());
//        for (Agendavel agendavel : agendaveis) statusAgendamentos.add(agendavel.monitorar());
//        return statusAgendamentos;
        return agendaveis.stream()
                .map(Agendavel::monitorar)
                .filter(StatusAgendamento.CONCLUIDA::equals)
                .toList();
    }
}
