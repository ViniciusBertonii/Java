public class BackupDeDados implements Agendavel {
    private String sistemaParaFazerBackup;
    private String horarioExec;
    private StatusAgendamento status;
    public BackupDeDados(String sistemaParaFazerBackup) {
        this.sistemaParaFazerBackup = sistemaParaFazerBackup;
    }
    public String getSistemaParaFazerBackup() {
        return sistemaParaFazerBackup;
    }
    @Override
    public void agendar(String horario) {
        if (foiAgendadoAlgumaVez())return;
        horarioExec = horario;
        this.status = StatusAgendamento.AGENDADA;
    }
    @Override
    public void executar() {
        this.status = StatusAgendamento.EM_EXEC;
    }
    @Override
    public StatusAgendamento monitorar() {
        return this.status;
    }
}
