public interface Agendavel {
    void agendar(String horario);
    void executar();
    StatusAgendamento monitorar();
    default boolean foiAgendadoAlgumaVez(){
        return monitorar() != null;
    }
}
