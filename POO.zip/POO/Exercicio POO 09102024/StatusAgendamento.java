public enum StatusAgendamento {
    AGENDADA,EM_EXEC,CONCLUIDA;
}
