public class Retangulo extends Figura {

	private double largura;

	private double comprimento;

	public Retangulo(double x, double y, double larg, double compr) {
		super(x, y);
		largura = Math.max(larg, 0.0);
		comprimento = Math.max(compr, 0.0);
	}

	public double getLargura() { return largura; }

	public double getComprimento() { return comprimento; }

	public double getArea() {
		return (largura * comprimento); 
	}

	@Override
	public double getPerimetro() {
		return (2*largura)+(2*comprimento);
	}

}
