public class Circulo extends Figura {

	private double raio;

	public Circulo(double x, double y, double raio) {
		super(x, y);
		this.raio = Math.max(raio, 0.0);
	}

	public double getRaio() {
		return raio;
	}

	public double getArea() {
		return (Math.PI * raio * raio);
	}

	public double getPerimetro() {
		return (2 * Math.PI * raio);
	}

}
