import java.util.ArrayList;

public class Tela {

	/**
	 * coleção de figuras dentro desta tela
	 */
	private ArrayList<Figura> figuras;

	public Tela() {
		figuras = new ArrayList<Figura>();
	}

	public void adicionarFigura(Figura fig) {
		figuras.add(fig);
	}

	public void desenhar() {
		double areaTotal = 0.0;
		double areaMedia = 0.0;
		int qtdFigurasVisiveis = 0;

		for (Figura fig : figuras) {
			if (fig.isVisivel()) {
				qtdFigurasVisiveis++;
				areaTotal += fig.getArea();
				System.out.println(fig);
			}
		}

		// evita divisão por zero
		if (qtdFigurasVisiveis > 0) {
			areaMedia = areaTotal / qtdFigurasVisiveis;
			System.out.println("Estatísticas das figuras visiveis:");
			System.out.printf("\tÁrea total: %.5f\n", areaTotal);
			System.out.printf("\tÁrea média: %.5f\n", areaMedia);
		}

	}

}
