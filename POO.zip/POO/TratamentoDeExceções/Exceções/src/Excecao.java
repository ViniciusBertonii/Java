public class Excecao {
        
    public double fatorial(int numero){
        if(numero<0){
            throw new IllegalArgumentException("Numero insetido Inválido");
        }

        

    }
    public static void main(String[] args) {
        
    }

}
