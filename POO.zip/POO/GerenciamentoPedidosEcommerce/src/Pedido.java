import java.util.ArrayList;
import java.util.List;


class Pedido {
    private List<ItemPedido> itens;
    private String nomeCliente;
    private String dataPedido;

    public Pedido(String nomeCliente, String dataPedido){
        this.nomeCliente = nomeCliente;
        this.dataPedido = dataPedido;
        this.itens = new ArrayList<>();
    }

    public void adicionarItem(Produto produto, int quantidade){
        if (produto.diminuirEstoque(quantidade)) {
            itens.add(new ItemPedido(produto, quantidade));
        }else{
            System.out.println("Sem Estoque");
        }

        public double getTotal() {
            double total = 0;
            for (ItemPedido item : itens) {
                total += item.getPrecoTotal();
            }
            return total;
        }

        public void imprimirDetalhesPedido(){
            System.out.println("Detalhes do Pedido:");

            System.out.println("Cliente", nomeCliente);

            System.out.println("data: ", dataPedido);

            for (ItemPedido item : itens) {
                System.out.println(item.getProduto().getNome() + " | Quantidade: " + item.getQuantidade() + " | Total: R$ ", item.getPrecoTotal());
            }
            System.out.println("Total do pedido: R$ ", getTotal);
        }
    }



}
