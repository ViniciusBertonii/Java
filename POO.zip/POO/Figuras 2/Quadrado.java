public class Quadrado extends Figura {

	private double lado;

	public Quadrado(double x, double y, double lado) {
		super(x, y);
		this.lado = Math.max(lado, 0.0);
	}

	public double getLado() {
		return lado;
	}

	public double getArea() {
		return (lado * lado);
	}

	
	@Override
    public double getPerimetro(){
        return 4*lado;
    }

}
