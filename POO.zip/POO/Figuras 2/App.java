public class App {
    public static void main(String[] args) {
        Tela t = new Tela();
        t.adicionarFigura(new Retangulo(10, 10, 5, 5));
        t.adicionarFigura(new Circulo(20, 20, 5));
        t.adicionarFigura(new Quadrado(30, 30, 5));
        CaixaDeTexto cx1 = new CaixaDeTexto(100,200, "Marcos Vinicius Bertoni Ferreira");

        Circulo c1 = new Circulo(12.3, 9.8, 3.2);
        c1.setVisivel(false);
        t.adicionarFigura(c1);
        t.adicionarFigura(cx1);
        
        t.desenhar();
        
    }
}
