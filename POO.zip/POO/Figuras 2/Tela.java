import java.util.ArrayList;

public class Tela {

	/**
	 * coleção de figuras dentro desta tela
	 */
	private ArrayList<Figura> figuras;

	public Tela() {
		figuras = new ArrayList<Figura>();
	}

	public void adicionarFigura(Figura fig) {
		figuras.add(fig);
	}

	public void desenhar() {
		double areaTotal = 0.0;
		double areaMedia = 0.0;
		double perimetroTotal = 0.0;
		int qtdFigurasVisiveis = 0;

		for (Figura fig : figuras) {
			if (fig.isVisivel()) {
				qtdFigurasVisiveis++;
				areaTotal += fig.getArea();
				perimetroTotal+=fig.getPerimetro();
				System.out.println(fig);
			}
		}

		// evita divisão por zero
		if (qtdFigurasVisiveis > 0) {
			areaMedia = areaTotal / qtdFigurasVisiveis;
			System.out.println("Estatísticas das figuras visiveis:");
			System.out.printf("\tÁrea total: %.5f\n", areaTotal);
			System.out.printf("\tÁrea média: %.5f\n", areaMedia);
			System.out.printf("\tPerímetro total: %.5f\n", perimetroTotal);
		}

	}

	public ArrayList<Figura> figuraMaiorQue(double areaCorte) {
		ArrayList<Figura> figuraMaiorQue = new ArrayList<>();

		for (Figura fig : figuras) {
			if (fig.getArea() > areaCorte) {
				figuraMaiorQue.add(fig);
			}
		}

		return figuraMaiorQue;
	}

	

	

}
