public class CaixaDeTexto extends Retangulo {
    private String texto;

    private static final double ALTURA_FIXA = 28.0;
    private static final double LARGURA_POR_CARACTERE = 12.0;

    
    public CaixaDeTexto(double x, double y, String texto) {
        
        super(x, y, texto.length() * LARGURA_POR_CARACTERE, ALTURA_FIXA);
        this.texto = texto;
    }

    
    public String getTexto() {
        return texto;
    }

    
    @Override
    public String toString() {
        return  "Caixa De Texto: Largura = " + getLargura() + ", Altura = " + ALTURA_FIXA + ",Texto = " + texto;
    }

    
}