public abstract class Figura {

	private double posX;
	private double posY;
	private boolean visivel;

	public Figura(double x, double y) {
		posX = x;
		posY = y;
		visivel = true;	// por padrão, toda figura é visível
	}

	public double getX() {
		return posX;
	}

	public double getY() {
		return posY;
	}

	public void moverPara(double novoX, double novoY) {
		posX = novoX;
		posY = novoY;
	}

	public void setVisivel(boolean visivel) {
		this.visivel = visivel;
	}

	public boolean isVisivel() {
		return visivel;
	}

	/**
	 * Método abstrato, pois cada tipo de figura tem
	 * a sua própria maneira de calcular a área.
	 */
	public abstract double getArea();

	public abstract double getPerimetro();


	@Override
	public String toString() {
		return String.format("Figura %s na posição (%.2f, %.2f) com área %.5f e perímetro %.5f", 
			this.getClass().getName(), 
			posX, 
			posY, 
			getArea(), getPerimetro()	// chamada polimórfica
		);
	}

}
