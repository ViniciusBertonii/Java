public class Circulo {
    
    private double posX;
    private double posY;
    private double raio;

    public Circulo(double x, double y, double raio){
        setPosX(x);
        setPosY(y);
    }

    // Metodos
    public double getPosX() {
        return posX;
    }

    public double getPosY() {
        return posY;
    }

    public double getRaio() {
        return raio;
    }

    public double getArea(){
        return 3.1415 *raio*raio;
    }

    public double getCircunferencia(){
        return 2*3.1415*raio;
    }

    public void setPosX(double x) {
        if (x>=0.0) {
            this.posX=x;
        }else{
            this.posX=0.0;
        }
    }

    public void setPosY(double y) {
        if (y>=0.0) {
            this.posY=y;
        }else{
            this.posY=0.0;
        }
    }

    public void moverPara(double x, double y){
        if (x>=0.0 && y>=0.0){
            this.posX=x;
            this.posY=y;
        }
    }





}
