public class SalaoDeFestas {

    private Lustre[] lustres;
    
    private int qtdLampadasLustre;

    public SalaoDeFestas (int qtdLustres){
        
        
        // Define o minimo de lustres a ser criado e preenche o vetor de lustres com a quantidade minima de 2, assim como nas lampadas.

        int qtdLustresACriar = Math.max(qtdLustres, 2);
        lustres = new Lustre[qtdLustresACriar];

        
        //cria e armazena as lampadas

        for (int i=0; i<qtdLustresACriar; i++){
            lustres[i] = new Lustre(qtdLampadasLustre);
        }

    }

    public void LigasTodosOslustres(){
        for (int i=0; i<lustres.length; i++){
            lustres[i].ligar();
        }

    

    }

    public void DesligarTodosOsLustres(){
        for (int i=0; i<lustres.length; i++){
            lustres[i].desligar();
        }
    }

    public void LigarLustresPares(){
        for (int i = 0 ; i<lustres.length; i++){
            if ( i%2 == 0) {
                lustres[i].ligar();
            }
        }
    }

    public void DesligarLustresPares(){
        for (int i = 0 ; i<lustres.length; i++){
            if ( i%2 == 0) {
                lustres[i].desligar();;
            }
        }
    }

    public void LigarLustresImpares(){
        for (int i = 0 ; i<lustres.length; i++){
            if ( i%2 != 0) {
                lustres[i].ligar();
            }
        }
    }

    public void DesligarLustresImpares(){
        for (int i = 0 ; i<lustres.length; i++){
            if ( i%2 != 0) {
                lustres[i].desligar();;
            }
        }
    }


    public void PiscaLustre(int piscarXVezes){
        for (int i=0; i<lustres.length; i++){
            for(int j=0; j<piscarXVezes; j++){
                lustres[i].desligar();
                lustres[i].ligar();
            }
        } 
    }

    public int getLampadasQueimadasSalao(){
        int totalDeQueimadas=0;

        for (int i=0; i < lustres.length; i++){
            totalDeQueimadas += lustres[i].getQtdLampadasQueimadas();
        }

        return totalDeQueimadas;
    }


    }
    
    
