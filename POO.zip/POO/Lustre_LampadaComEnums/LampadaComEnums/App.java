import java.util.ArrayList;
import java.util.List;


public class App {
    public static void main(String[] args) {
        List<Lustre> lustres = new ArrayList<>();

        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));
        lustres.add(new Lustre(6));

        lustres.DesligarLustresPares();

        System.out.println(totalDeQueimadas());
    }
}
