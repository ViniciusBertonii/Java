import java.util.ArrayList;
import java.util.List;

import javax.xml.transform.TransformerFactoryConfigurationError;

public class Trasacao {
    private String date;
    private String type;
    private double amount;

public Transacao(String date, String type, double amount){
    this.date = date;
    this.type = type;
    this.amount = amount;

}
@Override
public String toString() {
    return String.format("%s | %s | %.2f", date, type, amount);


}


}
