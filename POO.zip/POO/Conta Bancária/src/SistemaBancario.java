import java.util.ArrayList;
import java.util.List;

// Classe que representa uma transação bancária
class Transacao {
    private String data;
    private String tipo;
    private double valor;

    public Transacao(String data, String tipo, double valor) {
        this.data = data;
        this.tipo = tipo;
        this.valor = valor;
    }

    @Override
    public String toString() {
        return String.format("%s | %s | %.2f", data, tipo, valor);
    }
}

// Classe que representa uma conta bancária
class ContaBancaria {
    private String numeroConta;
    private String titularConta;
    private double saldo;
    private List<Transacao> transacoes;

    public ContaBancaria(String numeroConta, String titularConta, double depositoInicial) {
        this.numeroConta = numeroConta;
        this.titularConta = titularConta;
        this.saldo = depositoInicial;
        this.transacoes = new ArrayList<>();
        this.transacoes.add(new Transacao("2024-08-22", "Depósito Inicial", depositoInicial));
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
            transacoes.add(new Transacao("2024-08-22", "Depósito", valor));
        } else {
            System.out.println("Valor de depósito inválido.");
        }
    }

    public void sacar(double valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
            transacoes.add(new Transacao("2024-08-22", "Saque", valor));
        } else {
            System.out.println("Valor inválido ou saldo insuficiente para saque.");
        }
    }

    public void imprimirExtrato() {
        System.out.println("Extrato da Conta para: " + titularConta);
        for (Transacao transacao : transacoes) {
            System.out.println(transacao);
        }
        System.out.println("Saldo Atual: " + saldo);
    }

    public double getSaldo() {
        return saldo;
    }

    public String getTitularConta() {
        return titularConta;
    }

    public String getNumeroConta() {
        return numeroConta;
    }
}

// Classe de teste para o sistema bancário
public class SistemaBancario {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("123456789", "João Silva", 1000.00);
        conta.depositar(500.00);
        conta.sacar(200.00);
        conta.imprimirExtrato();
    }
}
