import java.util.ArrayList;

public class ContaBancaria {
    private String numeroConta;
    private String titularConta;
    private double saldo;
    private list<Transacao> transacoes;

    public ContaBancaria(String numeroConta, String titularConta, double depositoInicial){
         this.numeroConta = numeroConta;
         this.saldo = depositoInicial;
         this.titularConta = titularConta;
         this.transacoes = new ArrayList<>();
         this.transacoes.add(new Trasacao("26-08-2024", "Deposito Inicial", depositoInicial));

         public void depositar (double valor) {
            if (valor>0) {
                saldo += valor;
                transacoes.add(new Trasacao("Depósito: ", valor));
            }else{
                System.out.println("Valor de depósito inválido.");
            }
         }

         public void sacar(double valor){
            if (valor>=0) {
                saldo-=valor;
                transacoes.add("saque", valor)


            }else{
                System.out.println("valor para saque invádlido.");
            }
         }

         public void ImprimirExtrato(){
            System.out.println("Extrato da conta para: ", titularConta);

            for (Transaco  Transacao : transacoes) {
                System.out.println(transacao);
            }

            System.out.println("Saldo atual: ", saldo);

         }

         public double getSaldo (){
            return saldo;
         }

         public String getTitularConta(){
            return titularConta;
         }

         public String numeroConta(){
            return numeroConta;
         }

        


     }
}
