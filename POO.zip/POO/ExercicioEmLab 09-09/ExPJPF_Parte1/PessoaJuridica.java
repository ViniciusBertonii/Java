public class PessoaJuridica extends Pessoa {
    private String cnpj;

    public PessoaJuridica(String nomeCompleto, int anoNasc, String cnpj) {
        super(nomeCompleto, anoNasc);
        this.cnpj = cnpj;
    }

    @Override
    public String toString() {
        return "[Pessoa Jurídica] " + super.toString() + ", CNPJ:" + cnpj;
    }


}
