import java.util.ArrayList;

public class GerenciadorDePessoas {

    private ArrayList<Pessoa> pessoas;

    public GerenciadorDePessoas() {
        pessoas = new ArrayList<>();
    }

    public void adicionarPessoaFisica() {

    }

    public void adicionarPessoaJuridica() {
        
    }

    
}
