import java.util.ArrayList;

public class App {
    public static void main(String[] args) {
        
        PessoaFisica pf1 = new PessoaFisica("Daniel Callegari", 2000, "123.123.123-12");
        PessoaFisica pf2 = new PessoaFisica("Maria", 1970, "234.234.234-50");
        PessoaJuridica pj1 = new PessoaJuridica("PUCRS", 1970, "08.623.091-0001/12");

        ArrayList<Pessoa> pessoas = new ArrayList<>();

        pessoas.add(pf1);
        pessoas.add(pf2);
        pessoas.add(pj1);

        // mostrar todo mundo
        for (Pessoa p : pessoas) {
            System.out.println(p);
        }

        String stringDeBusca = "1970";
        System.out.printf("Buscando por %s...\n", stringDeBusca);
        boolean achouPeloMenosUm = false;
        for (Pessoa p : pessoas) {
            if (p.toString().contains(stringDeBusca)) {
                achouPeloMenosUm = true;
                System.out.println(p);
            }
        }

        if (!achouPeloMenosUm) {
            System.out.println("Nenhum registro encontrado.");
        }



    }
}
