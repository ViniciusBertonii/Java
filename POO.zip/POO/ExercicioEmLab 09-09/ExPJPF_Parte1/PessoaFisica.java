public class PessoaFisica extends Pessoa {
    private String cpf;

    public PessoaFisica(String nomeCompleto, int anoNasc, String cpf) {
        super(nomeCompleto, anoNasc);
        this.cpf = cpf;
    }

    @Override
    public String toString() {
        return "[Pessoa Física] " + super.toString() + ", CPF:" + cpf;
    }

}
