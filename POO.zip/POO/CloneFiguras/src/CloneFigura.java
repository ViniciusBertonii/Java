public abstract class CloneFigura {

    private double posX;
    private double posY;
    private boolean visivel;
    

    public CloneFigura(double x, double y){
        posX = x;
        posY = y;
        visivel = true;
    }

    public double getX(){
        return posX;
    }

    public double getY() {
        return posY;
    }

    public void moverPara(double novoX, double novoY){
        posX = novoX;
        posY = novoY;
    }

    public void setVisivel(boolean visivel){
        this.visivel = visivel;
    }

    public boolean isVisivel(){
        return visivel;
    }

    /**
     Metodo abstrato pois cada tipo de figura tem a sua propria maneira de calcular a area
      
     */
    public abstract double getArea();
    public abstract double getPerimetro();

    @Override
    public String toString() {
        return String.format("Figura %s na posicão (%.2f, %.2f)", this.getClass().getName(),posX,posY, getArea());
    }

    }


    
