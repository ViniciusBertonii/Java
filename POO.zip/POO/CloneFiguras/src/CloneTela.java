import java.util.ArrayList;

public class CloneTela {
    
    /**
     * colecao de figuras dentro desta tela
     */

     private ArrayList<CloneFigura> figuras;

     public CloneTela(){
        figuras = new ArrayList<CloneFigura>();
     }

     public void adicionarFigura(CloneFigura fig){
        figuras.add(fig);
     }

     public void desenhar(){
        double areaTotal = 0.0;
        double areaMedia = 0.0;
        int qtdFigurasVisiveis = 0;

        for (CloneFigura fig : figuras){
            if (fig.isVisivel()) {
                qtdFigurasVisiveis++;
                areaTotal += fig.getArea();
                System.out.println(fig);
            }
        }

        //evita a divisao por zero
        if (qtdFigurasVisiveis>0) {
            areaMedia = areaTotal/qtdFigurasVisiveis;
            System.out.println("Estatisticas das figuras visiveis CloneNotSupportedException");
            System.out.printf("\tArea total: %.5f\n", areaTotal);
            System.out.printf("\tArea media: %.5f\n", areaMedia);
        }
     }
}
