import java.util.function.Consumer;

public class CloneApp {
    public static void main(String[] args) throws Exception {
        FiguraFactory factory = new FiguraFactory();
        CloneTela tela = new CloneTela();

        Consumer<CloneFigura> addToTela = tela::adicionarFigura;
        Consumer<CloneFigura> setInvisible = figura -> figura.setVisivel(false);

        Pipeline<CloneFigura> pipeline = new Pipeline<>(addToTela);

        pipeline.adicionar(factory.criarRetangulo(10, 10, 5, 5))
                .adicionar(factory.criarCirculo(20, 20, 5))
                .adicionar(factory.criarQuadrado(30, 30, 5))
                .adicionar(setInvisible, factory.criarCirculo(12.3, 9.8, 3.2))
                .executar();

        tela.desenhar();
    }
}

class Pipeline<T> {
    private final Consumer<T> consumer;
    private final Pipeline<T> next;

    public Pipeline(Consumer<T> consumer) {
        this(consumer, null);
    }

    private Pipeline(Consumer<T> consumer, Pipeline<T> next) {
        this.consumer = consumer;
        this.next = next;
    }

    public Pipeline<T> adicionar(T item) {
        consumer.accept(item);
        return next != null ? next.adicionar(item) : this;
    }

    public Pipeline<T> adicionar(Consumer<T> additionalConsumer, T item) {
        additionalConsumer.accept(item);
        return adicionar(item);
    }

    public Pipeline<T> proximo(Consumer<T> nextConsumer) {
        return new Pipeline<>(consumer, new Pipeline<>(nextConsumer));
    }

    public void executar() {
        // The pipeline execution is done in the adicionar method
    }
}
