
public class FiguraFactory {

}
