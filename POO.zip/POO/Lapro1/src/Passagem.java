// Classe base Passagem
public abstract class Passagem {
    protected double precoPorKg = 0.50;
    protected double precoAssento = 5.00;
    protected double precoPassagem;
    protected boolean direitoAMilhas;

    public Passagem(double precoPassagem) {
        this.precoPassagem = precoPassagem;
    }

    // Método abstrato para calcular o custo da bagagem
    public abstract double custoBagagem(int quantidadeDeBagagens, double[] pesos);

    // Método para definir o custo do assento (algumas categorias podem sobrepor)
    public double defineAssento(String identificadorAssento) {
        return precoAssento;
    }

    // Método abstrato para calcular milhas
    public abstract double calcularMilhas();
}

// Categoria Economy
class Economy extends Passagem {
    public Economy(double precoPassagem) {
        super(precoPassagem);
        this.direitoAMilhas = false;
    }

    @Override
    public double custoBagagem(int quantidadeDeBagagens, double[] pesos) {
        double custoTotal = 0.0;
        for (int i = 0; i < quantidadeDeBagagens; i++) {
            custoTotal += (pesos[i] * precoPorKg) + 10.00; // Adicional de R$10 por bagagem
        }
        return custoTotal;
    }

    @Override
    public double calcularMilhas() {
        return 0; // Economy não acumula milhas
    }
}

// Categoria Executive
class Executive extends Passagem {
    public Executive(double precoPassagem) {
        super(precoPassagem);
        this.direitoAMilhas = true;
    }

    @Override
    public double custoBagagem(int quantidadeDeBagagens, double[] pesos) {
        double custoTotal = 0.0;
        for (int i = 0; i < quantidadeDeBagagens; i++) {
            if (i >= 2) { // As duas primeiras bagagens são isentas
                custoTotal += pesos[i] * precoPorKg;
            }
        }
        return custoTotal;
    }

    @Override
    public double calcularMilhas() {
        return precoPassagem * 0.10; // 10% do valor da passagem em milhas
    }
}

// Categoria Premier
class Premier extends Passagem {
    public Premier(double precoPassagem) {
        super(precoPassagem);
        this.direitoAMilhas = true;
        this.precoAssento = 0; // Marcação de assento é gratuita
    }

    @Override
    public double custoBagagem(int quantidadeDeBagagens, double[] pesos) {
        double custoTotal = 0.0;
        for (int i = 0; i < quantidadeDeBagagens; i++) {
            custoTotal += (pesos[i] * precoPorKg * 0.5); // 50% de desconto nas bagagens
        }
        return custoTotal;
    }

    @Override
    public double calcularMilhas() {
        return precoPassagem * 0.20; // 20% do valor da passagem em milhas
    }

    @Override
    public double defineAssento(String identificadorAssento) {
        return 0; // Sem custo para marcação de assento
    }
}











