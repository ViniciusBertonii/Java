// Exemplo de uso
public class AppPassagem {
    public static void main(String[] args) {
        Passagem economy = new Economy(1000);
        Passagem executive = new Executive(2000);
        Passagem premier = new Premier(3000);

        double[] pesos = {20, 25, 15}; // Exemplo de pesos de bagagem

        System.out.println("Economy - Custo Bagagem: R$ " + economy.custoBagagem(3, pesos));
        System.out.println("Economy - Milhas: " + economy.calcularMilhas());

        System.out.println("Executive - Custo Bagagem: R$ " + executive.custoBagagem(3, pesos));
        System.out.println("Executive - Milhas: " + executive.calcularMilhas());

        System.out.println("Premier - Custo Bagagem: R$ " + premier.custoBagagem(3, pesos));
        System.out.println("Premier - Milhas: " + premier.calcularMilhas());
        System.out.println("Premier - Custo Assento: R$ " + premier.defineAssento("15F"));
    }
}