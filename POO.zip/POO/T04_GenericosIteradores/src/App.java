import java.util.Iterator;

/* public class App {
    public static void main(String[] args) throws Exception {
        //MyList<Caneta> canetas = new MyLinkedList<>();
        MyList<Caneta> canetas = new MyArrayList<>();

        canetas.add(new Caneta("Azul", "Bic"));
        canetas.add(new Caneta("Azul", "Pilot"));
        canetas.add(new Caneta("Vermelha", "Bic"));
        canetas.add(new Caneta("Vermelha", "Pilot"));

        //The worst "for" ever seen for linked lists(O2)
        System.out.println("Percorre a lista usando get");
        for(int i=0;i<canetas.size();i++){
            System.out.println(canetas.get(i));
        }
        System.out.println("Percorre a lista usando iterador");
        Iterator<Caneta> it = canetas.getIterator();
        while(it.hasNext()){
            Caneta aux = it.next();
            System.out.println(aux);
        }
    }
}
*/