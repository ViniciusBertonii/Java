import java.util.Iterator;

public class MyLinkedList<E> implements MyList<E> {
    private class Node<T>{
        public T element;
        public Node<T> next;

        public Node(T element){
            this.element = element;
            this.next = null;
        }
    }

    class MyIterator<U> implements Iterator<U>{
        private Node<U> current;

        public MyIterator(){
            current = (Node<U>)head;
        }

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public U next() {
            U element = current.element;
            current = current.next;
            return element;
        }  
    }

    private Node<E> head;
    private Node<E> tail;
    private int size;

    public MyLinkedList(){
        this.head = null;
        this.tail = null;
        this.size = 0;
    }

    @Override
    public void add(E element) {
        Node<E> newNode = new Node<>(element);
        if (head == null){
            head = newNode;
            tail = head;
            size = 1;
            return;
        }
        tail.next = newNode;
        tail = newNode;
        size++;
    }

    @Override
    public E get(int i) {
        if (i < 0 || i >=size ){
            throw new IndexOutOfBoundsException("Valor de i invalido: "+i);
        }
        Node<E> aux = head;
        for(int c=0;c < i;c++){
            aux = aux.next;
        }
        return aux.element;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public Iterator<E> getIterator(){
        return new MyIterator<E>();
    }

    @Override
    public E remove(E element) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'remove'");
    }

    @Override
    public void add(int i, E element) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'add'");
    }
}
