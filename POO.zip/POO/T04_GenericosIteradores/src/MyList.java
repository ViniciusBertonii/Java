// Interface genérica para lista

import java.util.Iterator;

interface MyList<E>{
    void add(E element);
    E get(int i);
    int size();
    E remove(E element);
    void add(int i,E element);
    Iterator<E> getIterator();
}